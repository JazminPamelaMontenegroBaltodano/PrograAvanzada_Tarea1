# Tarea Programada 1 - Programación Avanzada
# Carné: FI23032284

# Repositorio
- https://github.com/JazminPamelaMontenegroBaltodano/PrograAvanzada_Tarea1

# Fuentes consultadas
- https://www.youtube.com/watch?v=m8BAZ0L_cYU&ab_channel=ShaunHalverson
- https://letstalkscience.ca/educational-resources/backgrounders/fibonacci-and-golden-ratio#:~:text=The%20Golden%20Ratio%20is%20a,the%20answers%20get%20to%20Phi.
- https://www.youtube.com/watch?v=2tv6Ej6JVho&ab_channel=ScienceABC


# Prompts de IA utilizados
# Herramienta: ChatGPT  
# Prompt: Cómo calcular el número aureo usando Fibonacci en C# de forma iterativa?

# Respuesta: Calcular el número áureo usando la sucesión de Fibonacci de forma iterativa en C# es sencillo. La idea es que a medida que los números de Fibonacci crecen, el cociente entre dos números consecutivos de la sucesión tiende al número áureo (aproximadamente 1.61803...).

# Fórmula

#  𝜙≈𝐹(𝑛)
#    𝐹(𝑛−1)   para un "n" grande

# Ejemplo de implementación en C# (iterativo)

using System;

class NumeroAureo
{
    static void Main()
    {
        int n = 30; // Puedes aumentar este número para mayor precisión

        double fibNMinus1 = 1;
        double fibN = 1;

        for (int i = 2; i <= n; i++)
        {
            double temp = fibN;
            fibN = fibN + fibNMinus1;
            fibNMinus1 = temp;
        }

        double numeroAureo = fibN / fibNMinus1;

        Console.WriteLine($"Aproximación del número áureo con Fibonacci({n}) / Fibonacci({n - 1}) = {numeroAureo}");
    }
}

# Explicación:
# Se usan dos variables para llevar el control de los dos últimos números de Fibonacci.
# Se itera n veces para construir el número F(n) de forma iterativa.
# Luego se calcula el cociente F(n) / F(n-1) como aproximación al número áureo.

# Resultado esperado:
# Con n = 30, la salida será algo similar a:
# Aproximación del número áureo con Fibonacci(30) / Fibonacci(29) = 1.618033988749895