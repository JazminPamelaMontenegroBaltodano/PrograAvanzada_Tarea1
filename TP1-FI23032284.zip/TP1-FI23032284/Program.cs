﻿using System;
using System.Globalization;

namespace TP1_FI23032284
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Type an integer from 2 to 45: ");
            string input = Console.ReadLine();

            if (!int.TryParse(input, out int n) || n < 2 || n > 45)
            {
                Console.WriteLine("Input is out of range");
                Console.ReadLine();
                return;
            }

            Console.WriteLine($"You typed: {n}");

            // Calcular phi con 15 decimales
            double phi = (1 + Math.Sqrt(5)) / 2;
            Console.WriteLine($"Phi ~ {phi.ToString("0.000000000000000", CultureInfo.InvariantCulture)}");

            // Usar long para Fibonacci y evitar overflow
            long[] fib = new long[n + 1];
            fib[0] = 0;
            fib[1] = 1;
            for (int i = 2; i <= n; i++)
            {
                fib[i] = fib[i - 1] + fib[i - 2];
            }

            // Calcular y mostrar aproximaciones y diferencias
            for (int i = 2; i <= n; i++)
            {
                double approx = (double)fib[i] / fib[i - 1];
                double diff = Math.Abs(phi - approx); // Valor absoluto garantizado

                string approxStr = approx.ToString("0.################", CultureInfo.InvariantCulture);
                string diffStr = diff.ToString("0.000000000000000", CultureInfo.InvariantCulture); // sin signo

                Console.WriteLine($"Fib({i}) / Fib({i - 1}) ~ {approxStr} [ {diffStr}]");
            }

            // Mostrar últimos valores de Fibonacci
            Console.WriteLine($"Fib({n}) = {fib[n]}");
            Console.WriteLine($"Fib({n - 1}) = {fib[n - 1]}");

            Console.ReadLine();
        }
    }
}
